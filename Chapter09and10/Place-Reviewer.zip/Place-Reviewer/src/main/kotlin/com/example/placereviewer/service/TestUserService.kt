package com.example.placereviewer.service

import com.example.placereviewer.data.model.User

interface TestUserService {

    fun getUser(): User
}