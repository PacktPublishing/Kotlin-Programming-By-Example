package com.example.messenger.api.repositories

import com.example.messenger.api.models.User
import org.springframework.data.repository.CrudRepository

/**
 * @author Iyanu Adelekan on 08/10/2017.
 */
interface UserRepository : CrudRepository<User, Long> {

    fun findByUsername(username: String): User?

    fun findByPhoneNumber(phoneNumber: String): User?
}