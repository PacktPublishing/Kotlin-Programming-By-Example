package com.example.messenger.api.security

/**
 * @author Iyanu Adelekan on 12/10/2017.
 */

class AccountCredentials {
    lateinit var username: String
    lateinit var password: String
}