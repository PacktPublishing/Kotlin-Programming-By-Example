package com.example.messenger.api.services

import javax.servlet.http.HttpServletRequest

/**
 * @author Iyanu Adelekan on 18/10/2017.
 */
interface RequestLogService {

    fun logRequest(request: HttpServletRequest)
}