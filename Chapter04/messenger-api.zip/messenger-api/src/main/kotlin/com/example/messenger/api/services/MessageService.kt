package com.example.messenger.api.services

import com.example.messenger.api.models.Message
import com.example.messenger.api.models.User

/**
 * @author Iyanu Adelekan on 18/10/2017.
 */
interface MessageService {

    fun sendMessage(sender: User, recipientId: Long, messageText: String): Message
}