package com.example.messenger.api.constants

/**
 * @author Iyanu Adelekan on 20/10/2017.
 */
class ErrorResponse(val errorCode: String, val errorMessage: String)