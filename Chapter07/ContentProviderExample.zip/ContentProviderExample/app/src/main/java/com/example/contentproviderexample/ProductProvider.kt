package com.example.contentproviderexample

import android.content.*
import android.database.Cursor
import android.database.SQLException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.database.sqlite.SQLiteQueryBuilder
import android.net.Uri
import android.text.TextUtils

/**
 * @author Iyanu Adelekan. 10/12/2017.
 */
internal class ProductProvider : ContentProvider() {

    companion object {

        val PROVIDER_NAME: String = "com.example.contentproviderexample.ProductProvider"
        val URL: String = "content://$PROVIDER_NAME/products"
        val CONTENT_URI: Uri = Uri.parse(URL)

        val PRODUCTS = 1
        val PRODUCT_ID = 2

        // Database and table property declarations
        val DATABASE_VERSION = 1
        val DATABASE_NAME = "Depot"
        val PRODUCTS_TABLE_NAME = "products"

        // 'products' table column name declarations
        val ID: String = "id"
        val NAME: String = "name"
        val MANUFACTURER: String = "manufacturer"

        val uriMatcher: UriMatcher = UriMatcher(UriMatcher.NO_MATCH)
        val PRODUCTS_PROJECTION_MAP: HashMap<String, String> = HashMap()

        /**
         * SQLiteOpenHelper class that creates the
         * content provider's database
         */
        private class DatabaseHelper(context: Context) :
                SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

            override fun onCreate(db: SQLiteDatabase) {
                val query = " CREATE TABLE " + PRODUCTS_TABLE_NAME +
                        " (id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        " name VARCHAR(255) NOT NULL, " +
                        " manufacturer VARCHAR(255) NOT NULL);"

                db.execSQL(query)
            }

            override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
                val query = "DROP TABLE IF EXISTS $PRODUCTS_TABLE_NAME"

                db.execSQL(query)
                onCreate(db)
            }
        }
    }

    private lateinit var db: SQLiteDatabase

    override fun onCreate(): Boolean {
        uriMatcher.addURI(PROVIDER_NAME, "products", PRODUCTS)
        uriMatcher.addURI(PROVIDER_NAME, "products/#", PRODUCT_ID)

        val helper = DatabaseHelper(context)

        /**
         * Use the SQLiteOpenHelper to get a writable database.
         * A new database is created if one does not already exist.
         */
        db = helper.writableDatabase

        return true
    }

    override fun insert(uri: Uri, values: ContentValues): Uri {
        /*
         * Insert a new product record into the products table
         */
        val rowId = db.insert(PRODUCTS_TABLE_NAME, "", values)

        /*
         * If rowId is greater than 0 then the product record
         * was added successfully.
         */
        if (rowId > 0) {
            val _uri = ContentUris.withAppendedId(CONTENT_URI, rowId)
            context.contentResolver.notifyChange(_uri, null)

            return _uri
        }

        // throws an exception if the product was not successfully added.
        throw SQLException("Failed to add product into " + uri)
    }

    override fun query(uri: Uri, projection: Array<String>?,
                       selection: String?, selectionArgs: Array<String>?,
                       sortOrder: String): Cursor {

        val queryBuilder = SQLiteQueryBuilder()
        queryBuilder.tables = PRODUCTS_TABLE_NAME

        when (uriMatcher.match(uri)) {
            PRODUCTS -> queryBuilder.setProjectionMap(PRODUCTS_PROJECTION_MAP)
            PRODUCT_ID -> queryBuilder.appendWhere(  "$ID = ${uri.pathSegments[1]}")
        }

        val cursor: Cursor = queryBuilder.query(db,	projection,	selection, selectionArgs,
                null, null, sortOrder)

        cursor.setNotificationUri(context.contentResolver, uri)
        return cursor
    }

    override fun delete(uri: Uri, selection: String, selectionArgs: Array<String>): Int {

        val count = when(uriMatcher.match(uri)) {

            PRODUCTS -> db.delete(PRODUCTS_TABLE_NAME, selection, selectionArgs)
            PRODUCT_ID -> {
                val id = uri.pathSegments[1]
                db.delete(PRODUCTS_TABLE_NAME, "$ID = $id " +
                        if (!TextUtils.isEmpty(selection)) "AND ($selection)" else "", selectionArgs)
            }
            else -> throw IllegalArgumentException("Unknown URI: $uri")
        }

        context.contentResolver.notifyChange(uri, null)
        return count
    }

    override fun update(uri: Uri, values: ContentValues, selection: String,
                        selectionArgs: Array<String>): Int {

        val count = when(uriMatcher.match(uri)) {
            PRODUCTS ->
                db.update(PRODUCTS_TABLE_NAME, values, selection, selectionArgs)
            PRODUCT_ID -> {
                db.update(PRODUCTS_TABLE_NAME, values,
                        "$ID = ${uri.pathSegments[1]} " +
                                if (!TextUtils.isEmpty(selection)) " AND ($selection)" else "", selectionArgs)
            }
            else -> throw  IllegalArgumentException("Unknown URI: $uri")
        }

        context.contentResolver.notifyChange(uri, null)
        return count
    }

    override fun getType(uri: Uri): String {
        /*
         * Returns the appropriate MIME type of records
         */
        return when (uriMatcher.match(uri)){
            PRODUCTS -> "vnd.android.cursor.dir/vnd.example.products"
            PRODUCT_ID -> "vnd.android.cursor.item/vnd.example.products"
            else -> throw IllegalArgumentException("Unpermitted URI: " + uri)
        }
    }
}