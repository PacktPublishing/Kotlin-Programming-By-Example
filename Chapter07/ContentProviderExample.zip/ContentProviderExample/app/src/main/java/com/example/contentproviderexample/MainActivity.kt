package com.example.contentproviderexample

import android.content.ContentValues
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var etProductName: EditText
    private lateinit var etProductManufacturer: EditText
    private lateinit var btnAddProduct: Button
    private lateinit var btnShowProduct: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        setupInstances()
    }

    private fun bindViews() {
        etProductName = findViewById(R.id.et_product_name)
        etProductManufacturer = findViewById(R.id.et_product_manufacturer)
        btnAddProduct = findViewById(R.id.btn_add_product)
        btnShowProduct = findViewById(R.id.btn_show_products)
    }

    private fun setupInstances() {
        btnAddProduct.setOnClickListener(this)
        btnShowProduct.setOnClickListener(this)
        supportActionBar?.hide()
    }

    private fun inputsValid(): Boolean {
        var inputsValid = true

        if (TextUtils.isEmpty(etProductName.text)) {
            etProductName.error = "Field required."
            etProductName.requestFocus()
            inputsValid = false

        } else if (TextUtils.isEmpty(etProductManufacturer.text)) {
            etProductManufacturer.error = "Field required."
            etProductManufacturer.requestFocus()
            inputsValid = false
        }

        return inputsValid
    }

    private fun addProduct() {
        val contentValues = ContentValues()

        contentValues.put(ProductProvider.NAME, etProductName.text.toString())
        contentValues.put(ProductProvider.MANUFACTURER, etProductManufacturer.text.toString())
        contentResolver.insert(ProductProvider.CONTENT_URI, contentValues)

        showSaveSuccess()
    }

    private fun showProducts() {
        val uri = Uri.parse(ProductProvider.URL)
        val cursor = managedQuery(uri, null, null, null, "name")

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    val res = "ID: ${cursor.getString(cursor.getColumnIndex(ProductProvider.ID))}" +
                            ", \nPRODUCT NAME: ${cursor.getString(cursor.getColumnIndex( ProductProvider.NAME))}" +
                            ", \nPRODUCT MANUFACTURER: ${cursor.getString(cursor.getColumnIndex( ProductProvider.MANUFACTURER))}"

                    Toast.makeText(this, res, Toast.LENGTH_LONG).show()
                } while (cursor.moveToNext())
            }
        } else {
            Toast.makeText(this, "Oops, something went wrong.", Toast.LENGTH_LONG).show()
        }
    }

    private fun showSaveSuccess() {
        Toast.makeText(this, "Product successfully saved.", Toast.LENGTH_LONG).show()
    }

    override fun onClick(view: View) {
        val id = view.id

        if (id == R.id.btn_add_product) {
            if (inputsValid()) {
                addProduct()
            }
        } else if (id == R.id.btn_show_products) {
            showProducts()
        }
    }
}