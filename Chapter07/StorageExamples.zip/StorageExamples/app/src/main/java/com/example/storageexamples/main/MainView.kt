package com.example.storageexamples.main

import com.example.storageexamples.base.BaseView

/**
 * @author Iyanu Adelekan. 03/12/2017.
 */
interface MainView : BaseView {

    fun navigateToHome()

    fun navigateToContent()
}