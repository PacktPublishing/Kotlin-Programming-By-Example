package com.example.storageexamples.main

import android.content.Context
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.Fragment
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.example.storageexamples.R
import com.example.storageexamples.base.BaseView
import java.io.FileInputStream
import java.io.FileOutputStream

class MainActivity : AppCompatActivity(), MainView {

    private lateinit var llContainer: LinearLayout

    // setting up fragment instances
    private lateinit var homeFragment: HomeFragment
    private lateinit var contentFragment: ContentFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupInstances()
        bindViews()
        navigateToHome()
    }

    override fun bindViews() {
        llContainer = findViewById(R.id.ll_container)
    }

    override fun setupInstances() {
        homeFragment = HomeFragment()
        contentFragment = ContentFragment()
    }

    private fun hideHomeNavigation() {
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
    }

    private fun showHomeNavigation() {
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun navigateToHome() {
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.ll_container, homeFragment)
        transaction.commit()

        supportActionBar?.title = "Home"
    }

    override fun navigateToContent() {
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.ll_container, contentFragment)
        transaction.commit()

        supportActionBar?.title = "File content"
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item?.itemId

        if (id == android.R.id.home) {
            navigateToHome()
            hideHomeNavigation()
        }

        return super.onOptionsItemSelected(item)
    }

    class HomeFragment : Fragment(), BaseView, View.OnClickListener {

        private lateinit var layout: LinearLayout
        private lateinit var tvHeader: TextView
        private lateinit var etInput: EditText
        private lateinit var btnSubmit: Button
        private lateinit var btnViewFile: Button

        private var outputStream: FileOutputStream? = null


        override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                  savedInstanceState: Bundle?): View {

            // inflate the fragment_home.xml layout
            layout = inflater.inflate(R.layout.fragment_home,
                    container, false) as LinearLayout
            setupInstances()
            bindViews()

            return layout
        }

        override fun bindViews() {
            tvHeader = layout.findViewById(R.id.tv_header)
            etInput = layout.findViewById(R.id.et_input)
            btnSubmit = layout.findViewById(R.id.btn_submit)
            btnViewFile = layout.findViewById(R.id.btn_view_file)

            btnSubmit.setOnClickListener(this)
            btnViewFile.setOnClickListener(this)
        }

        /**
         * Method for the instantiation of instance properties
         */
        override fun setupInstances() {
            /*
             * Open a new FileOutputStream to a file named 'content_file'.
             * This file is a private file stored in internal storage
             * and as such is only accessible by your application.
             */
            outputStream = activity?.openFileOutput("content_file", Context.MODE_PRIVATE)
        }

        /**
         * Called to display an error to the user if
         * an invalid input is given
         */
        private fun showInputError() {
            etInput.error = "File input cannot be empty."
            etInput.requestFocus()
        }

        /**
         * Writes string content to a file via a [FileOutputStream]
         */
        private fun writeFile(content: String) {
            outputStream?.write(content.toByteArray())
        }

        /**
         * Called to clear the input in the input field
         */
        private fun clearInput() {
            etInput.setText("")
        }

        /**
         * Shows a success message to the user when invoked.
         */
        private fun showSaveSuccess() {
            Toast.makeText(activity, "File updated successfully.", Toast.LENGTH_LONG).show()
        }

        override fun onClick(view: View?) {
            val id = view?.id

            if (id == R.id.btn_submit) {
                if (TextUtils.isEmpty(etInput.text)) {
                    /*
                     * Display an error message if the user submits
                     * an empty value as file content input
                     */
                    showInputError()
                } else {
                    /*
                     * Write content to the file, clear the input
                     * EditText and show a file update success message
                     */
                    writeFile(etInput.text.toString())
                    clearInput()
                    showSaveSuccess()
                }
            } else if (id == R.id.btn_view_file) {
                // retrieve a reference to MainActivity
                val mainActivity = activity as MainActivity

                /*
                 * Navigate user to the content fragment
                 * and display home button on action bar to
                 * enable a user go back to the previous fragment.
                 */
                mainActivity.navigateToContent()
                mainActivity.showHomeNavigation()
            }
        }
    }

    class ContentFragment : Fragment(), BaseView {

        private lateinit var layout: LinearLayout
        private lateinit var tvContent: TextView

        private lateinit var inputStream: FileInputStream

        override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                  savedInstanceState: Bundle?): View {

            layout = inflater.inflate(R.layout.fragment_content,
                    container, false) as LinearLayout
            setupInstances()
            bindViews()

            return layout
        }

        override fun onResume() {
            /*
             * Update content rendered in TextView upon
             * resumption of fragment
             */
            updateContent()
            super.onResume()
        }

        private fun updateContent() {
            tvContent.text = readFile()
        }

        override fun bindViews() {
            tvContent = layout.findViewById(R.id.tv_content)
        }

        override fun setupInstances() {
            inputStream = activity.openFileInput("content_file")
        }

        /**
         * Reads the content of file in internal storage
         * and returns content as a string.
         */
        private fun readFile(): String {
            var c: Int
            var content = ""

            c = inputStream.read()

            while (c != -1) {
                content += Character.toString(c.toChar())
                c = inputStream.read()
            }

            inputStream.close()

            return content
        }
    }
}