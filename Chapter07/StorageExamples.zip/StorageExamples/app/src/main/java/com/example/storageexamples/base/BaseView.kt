package com.example.storageexamples.base

/**
 * @author Iyanu Adelekan. 03/12/2017.
 */
interface BaseView {

    fun bindViews()

    fun setupInstances()
}