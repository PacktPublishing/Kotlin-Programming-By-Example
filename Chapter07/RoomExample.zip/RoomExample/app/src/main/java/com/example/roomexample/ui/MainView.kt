package com.example.roomexample.ui

/**
 * @author Iyanu Adelekan. 07/12/2017.
 */
interface MainView {

    fun bindViews()

    fun setupInstances()
}