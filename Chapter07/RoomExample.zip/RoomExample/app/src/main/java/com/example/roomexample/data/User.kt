package com.example.roomexample.data

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey

/**
 * @author Iyanu Adelekan. 07/12/2017.
 */
@Entity
data class User(
        @ColumnInfo(name = "first_name")
        var firstName: String = "",
        @ColumnInfo(name = "surname")
        var surname: String = "",
        @ColumnInfo(name = "phone_number")
        var phoneNumber: String = "",
        @PrimaryKey(autoGenerate = true)
        var id: Long = 0
)