package com.example.roomexample.ui

import android.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.example.roomexample.R
import com.example.roomexample.data.AppDatabase
import com.example.roomexample.data.User
import com.example.roomexample.data.UserDao
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        navigateToForm()
    }

    private fun showHomeButton() {
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    private fun hideHomeButton() {
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
    }

    private fun navigateToForm() {
        val transaction = fragmentManager.beginTransaction()
        transaction.add(R.id.ll_container, CreateUserFragment())
        transaction.commit()
    }

    override fun onBackPressed() {
        if (fragmentManager.backStackEntryCount > 0) {
            fragmentManager.popBackStack()
            hideHomeButton()
        } else {
            super.onBackPressed()
        }
    }

    private fun navigateToList() {
        val transaction = fragmentManager.beginTransaction()
        transaction.replace(R.id.ll_container, ListUsersFragment())
        transaction.addToBackStack(null)
        transaction.commit()
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item?.itemId

        if (id == android.R.id.home) {
            onBackPressed()
            hideHomeButton()
        }

        return super.onOptionsItemSelected(item)
    }

    class CreateUserFragment : Fragment(), MainView, View.OnClickListener {

        private lateinit var btnSubmit: Button
        private lateinit var etSurname: EditText
        private lateinit var btnViewUsers: Button
        private lateinit var layout: LinearLayout
        private lateinit var etFirstName: EditText
        private lateinit var etPhoneNumber: EditText

        private lateinit var userDao: UserDao
        private lateinit var appDatabase: AppDatabase

        override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                  savedInstanceState: Bundle?): View {
            layout = inflater.inflate(R.layout.fragment_create_user,
                    container, false) as LinearLayout
            bindViews()
            setupInstances()

            return layout
        }

        override fun bindViews() {
            btnSubmit = layout.findViewById(R.id.btn_submit)
            btnViewUsers = layout.findViewById(R.id.btn_view_users)
            etSurname = layout.findViewById(R.id.et_surname)
            etFirstName = layout.findViewById(R.id.et_first_name)
            etPhoneNumber = layout.findViewById(R.id.et_phone_number)

            btnSubmit.setOnClickListener(this)
            btnViewUsers.setOnClickListener(this)
        }

        override fun setupInstances() {
            appDatabase = AppDatabase.create(activity) // getting an instance of AppDatabase
            userDao = appDatabase.userDao() // getting an instance of UserDao
        }

        /**
         * Validates the inputs submitted in the create
         * a user form.
         * @return true if the input is valid and false otherwise.
         */
        private fun inputsValid(): Boolean {
            var inputValid = true
            val firstName = etFirstName.text
            val surname = etSurname.text
            val phoneNumber = etPhoneNumber.text

            if (TextUtils.isEmpty(firstName)) {
                etFirstName.error = "First name cannot be empty"
                etFirstName.requestFocus()
                inputValid = false

            } else if (TextUtils.isEmpty(surname)) {
                etSurname.error = "Surname cannot be empty"
                etSurname.requestFocus()
                inputValid = false

            } else if (TextUtils.isEmpty(phoneNumber)) {
                etPhoneNumber.error = "Phone number cannot be empty"
                etPhoneNumber.requestFocus()
                inputValid = false

            } else if (!android.util.Patterns.PHONE.matcher(phoneNumber).matches()) {
                etPhoneNumber.error = "Valid phone number required"
                etPhoneNumber.requestFocus()
                inputValid = false
            }

            return inputValid
        }

        private fun showCreationSuccess() {
            Toast.makeText(activity, "User successfully created.", Toast.LENGTH_LONG).show()
        }

        override fun onClick(view: View?) {
            val id = view?.id

            if (id == R.id.btn_submit) {
                if (inputsValid()) {
                    val user = User(
                            etFirstName.text.toString(),
                            etSurname.text.toString(),
                            etPhoneNumber.text.toString())

                    Observable.just(userDao)
                            .subscribeOn(Schedulers.io())
                            .subscribe( { dao ->
                                dao.insert(user)  // using UserDao to save user to database.
                                activity?.runOnUiThread { showCreationSuccess() }
                            }, Throwable::printStackTrace)
                }
            } else if (id == R.id.btn_view_users) {
                val mainActivity = activity as MainActivity

                mainActivity.navigateToList()
                mainActivity.showHomeButton()
            }
        }
    }

    class ListUsersFragment : Fragment(), MainView {

        private lateinit var layout: LinearLayout
        private lateinit var rvUsers: RecyclerView

        private lateinit var appDatabase: AppDatabase

        override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                  savedInstanceState: Bundle?): View {

            layout = inflater.inflate(R.layout.fragment_list_users,
                    container, false) as LinearLayout
            bindViews()
            setupInstances()

            return layout
        }

        override fun bindViews() {
            rvUsers = layout.findViewById(R.id.rv_users)
        }

        override fun setupInstances() {
            appDatabase = AppDatabase.create(activity)
            rvUsers.layoutManager = LinearLayoutManager(activity)
            rvUsers.adapter = UsersAdapter(appDatabase)
        }

        private class UsersAdapter(appDatabase: AppDatabase) : RecyclerView.Adapter<UsersAdapter.ViewHolder>() {

            private val users: ArrayList<User> = ArrayList()
            private val userDao: UserDao = appDatabase.userDao()

            init {
                populateUsers()
            }

            override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder {
                val layout = LayoutInflater.from(parent?.context)
                        .inflate(R.layout.vh_user, parent, false)

                return ViewHolder(layout)
            }

            override fun onBindViewHolder(holder: ViewHolder?, position: Int) {
                val layout = holder?.itemView
                val user = users[position]

                val tvFirstName = layout?.findViewById<TextView>(R.id.tv_first_name)
                val tvSurname = layout?.findViewById<TextView>(R.id.tv_surname)
                val tvPhoneNumber = layout?.findViewById<TextView>(R.id.tv_phone_number)

                tvFirstName?.text = "First name: ${user.firstName}"
                tvSurname?.text = "Surname: ${user.surname}"
                tvPhoneNumber?.text = "Phone number: ${user.phoneNumber}"
            }

            /**
             * Populates users ArrayList with User objects
             */
            private fun populateUsers() {
                users.clear()

                /**
                 * Get all users in the user table of the database.
                 * Upon successful retrieval of the list, add all
                 * User objects in the list to users ArrayList.
                 */
                userDao.all()
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe({ res ->
                            users.addAll(res)
                            notifyDataSetChanged()
                        }, Throwable::printStackTrace)
            }

            override fun getItemCount(): Int {
                return users.size
            }

            class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
        }
    }
}
