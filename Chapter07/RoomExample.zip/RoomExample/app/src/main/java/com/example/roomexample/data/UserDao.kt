package com.example.roomexample.data

import android.arch.persistence.room.Dao
import android.arch.persistence.room.Insert
import android.arch.persistence.room.OnConflictStrategy
import android.arch.persistence.room.Query
import io.reactivex.Flowable

/**
 * @author Iyanu Adelekan. 07/12/2017.
 */
@Dao
interface UserDao {

    @Query("SELECT * FROM user")
    fun all(): Flowable<List<User>>

    @Query("SELECT * FROM user WHERE id = :id")
    fun findById(id: Long): Flowable<User>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(user: User)
}