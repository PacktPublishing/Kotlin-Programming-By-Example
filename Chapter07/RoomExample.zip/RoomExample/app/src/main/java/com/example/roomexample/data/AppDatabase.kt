package com.example.roomexample.data

import android.arch.persistence.room.Database
import android.arch.persistence.room.Room
import android.arch.persistence.room.RoomDatabase
import android.content.Context

/**
 * @author Iyanu Adelekan. 07/12/2017.
 */
@Database(entities = [User::class], version = 1, exportSchema = false)
internal abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao

    companion object Factory {
        private var appDatabase: AppDatabase? = null

        fun create(ctx: Context): AppDatabase {
            if (appDatabase == null) {
                appDatabase = Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java,
                        "app-database").build()

            }

            return appDatabase as AppDatabase
        }
    }
}