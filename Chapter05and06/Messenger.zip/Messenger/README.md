# Messenger
A simple Messenger application to demonstrate the use of MVP in building Android apps.
