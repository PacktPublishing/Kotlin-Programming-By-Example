package com.example.messenger.ui.chat

import android.content.Context
import com.example.messenger.data.local.AppPreferences
import com.example.messenger.data.remote.repository.ConversationRepository
import com.example.messenger.data.remote.repository.ConversationRepositoryImpl
import com.example.messenger.data.remote.request.MessageRequestObject
import com.example.messenger.service.MessengerApiService
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

/**
 * @author Iyanu Adelekan. 29/10/2017.
 */
class ChatInteractorImpl(context: Context) : ChatInteractor {

    private val preferences: AppPreferences = AppPreferences.create(context)
    private val service: MessengerApiService = MessengerApiService.getInstance()
    private val conversationsRepository: ConversationRepository = ConversationRepositoryImpl(context)

    /**
     * Called to load the messages of a conversation thread
     * @param conversationId the unique id of the conversation opened
     * @param listener instance of the type [ChatInteractor.onMessageLoadFinishedListener]
     */
    override fun loadMessages(conversationId: Long, listener: ChatInteractor.onMessageLoadFinishedListener) {
        conversationsRepository.findConversationById(conversationId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ res -> listener.onLoadSuccess(res)},
                        { error ->
                            listener.onLoadError()
                            error.printStackTrace()})
    }

    /**
     * Called to send a message to a user
     * @param recipientId unique id of the message recipient
     * @param listener instance of the type [ChatInteractor.OnMessageSendFinishedListener]
     */
    override fun sendMessage(recipientId: Long, message: String,
                             listener: ChatInteractor.OnMessageSendFinishedListener) {
        service.createMessage(MessageRequestObject(recipientId, message), preferences.accessToken as String)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ _ -> listener.onSendSuccess()},
                        { error ->
                            listener.onSendError()
                            error.printStackTrace()})
    }
}