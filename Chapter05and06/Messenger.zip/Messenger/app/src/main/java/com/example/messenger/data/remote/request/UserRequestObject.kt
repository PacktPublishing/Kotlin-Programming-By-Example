package com.example.messenger.data.remote.request

/**
 * @author Iyanu Adelekan. 28/10/2017.
 */
data class UserRequestObject(
        val username: String,
        val password: String,
        val phoneNumber: String = ""
)