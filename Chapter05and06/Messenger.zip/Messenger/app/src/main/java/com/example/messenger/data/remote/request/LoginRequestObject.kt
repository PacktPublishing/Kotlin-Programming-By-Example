package com.example.messenger.data.remote.request

/**
 * @author Iyanu Adelekan. 28/10/2017.
 */
data class LoginRequestObject(
        val username: String,
        val password: String
)