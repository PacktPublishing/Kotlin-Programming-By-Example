package com.example.messenger.data.remote.repository

/**
 * @author Iyanu Adelekan. 27/10/2017.
 */
interface MessageRepository {
}