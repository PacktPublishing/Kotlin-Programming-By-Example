package com.example.messenger.data.remote.request

/**
 * @author Iyanu Adelekan. 01/11/2017.
 */
data class StatusUpdateRequestObject(val status: String)