package com.example.messenger.data.remote.repository

import android.content.Context
import com.example.messenger.service.MessengerApiService
import com.example.messenger.data.local.AppPreferences
import com.example.messenger.data.vo.ConversationListVO
import com.example.messenger.data.vo.ConversationVO
import io.reactivex.Observable

/**
 * @author Iyanu Adelekan. 27/10/2017.
 */
class ConversationRepositoryImpl(ctx: Context) : ConversationRepository {

    private val preferences: AppPreferences = AppPreferences.create(ctx)
    private val service: MessengerApiService = MessengerApiService.getInstance()

    override fun findConversationById(id: Long): Observable<ConversationVO> {
        return service.showConversation(id, preferences.accessToken as String)
    }

    override fun all(): Observable<ConversationListVO> {
        return service.listConversations(preferences.accessToken as String)
    }
}