package com.example.messenger.ui.main

import com.example.messenger.data.vo.ConversationListVO
import com.example.messenger.data.vo.UserListVO

/**
 * @author Iyanu Adelekan. 25/10/2017.
 */
class MainPresenterImpl(val view: MainView) : MainPresenter, MainInteractor.OnConversationsLoadFinishedListener,
        MainInteractor.OnContactsLoadFinishedListener, MainInteractor.OnLogoutFinishedListener {

    private val interactor: MainInteractor = MainInteractorImpl(view.getContext())

    override fun onConversationsLoadSuccess(conversationsListVo: ConversationListVO) {
        /*
         * Checking if currently logged in user has active conversations.
         */
        if (!conversationsListVo.conversations.isEmpty()) {
            val conversationsFragment = view.getConversationsFragment()
            val conversations = conversationsFragment.conversations
            val adapter = conversationsFragment.conversationsAdapter

            conversations.clear()
            adapter.notifyDataSetChanged()

            /*
             * Adding each conversation retrieved from API to ConversationFragment's
             * conversations list.
             * Conversations adapter is notified after every item addition.
             */
            conversationsListVo.conversations.forEach { contact ->
                conversations.add(contact)
                adapter.notifyItemInserted(conversations.size - 1)
            }
        } else {
            view.showNoConversations()
        }
    }

    override fun onConversationsLoadError() {
        view.showConversationsLoadError()
    }

    override fun onContactsLoadSuccess(userListVO: UserListVO) {
        val contactsFragment = view.getContactsFragment()
        val contacts = contactsFragment.contacts
        val adapter = contactsFragment.contactsAdapter

        /*
         * Clear previously loaded contacts in contacts list
         * and notify adapter pf data set change.
         */
        contacts.clear()
        adapter.notifyDataSetChanged()

        /*
         * Add each contact retrieved from API to ContactsFragment's
         * contacts list.
         * Contacts adapter is notified after every item addition.
         */
        userListVO.users.forEach { contact ->
            contacts.add(contact)
            contactsFragment.contactsAdapter.notifyItemInserted(contacts.size - 1)
        }
    }

    override fun onContactsLoadError() {
        view.showContactsLoadError()
    }

    override fun onLogoutSuccess() {
        view.navigateToLogin()
    }

    override fun loadConversations() {
        interactor.loadConversations(this)
    }

    override fun loadContacts() {
        interactor.loadContacts(this)
    }

    override fun executeLogout() {
        interactor.logout(this)
    }
}