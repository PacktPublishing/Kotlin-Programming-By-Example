package com.example.messenger.ui.signup

import com.example.messenger.data.local.AppPreferences

/**
 * @author Iyanu Adelekan. 25/10/2017.
 */
interface SignUpPresenter {
    var preferences: AppPreferences

    fun executeSignUp(username: String, phoneNumber: String, password: String)
}