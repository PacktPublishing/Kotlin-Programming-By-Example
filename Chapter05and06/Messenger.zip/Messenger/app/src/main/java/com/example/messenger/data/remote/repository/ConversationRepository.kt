package com.example.messenger.data.remote.repository

import com.example.messenger.data.vo.ConversationListVO
import com.example.messenger.data.vo.ConversationVO
import io.reactivex.Observable

/**
 * @author Iyanu Adelekan. 27/10/2017.
 */
interface ConversationRepository {
    fun findConversationById(id: Long): Observable<ConversationVO>

    fun all(): Observable<ConversationListVO>
}