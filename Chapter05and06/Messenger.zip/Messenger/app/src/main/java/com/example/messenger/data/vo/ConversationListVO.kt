package com.example.messenger.data.vo

/**
 * @author Iyanu Adelekan. 28/10/2017.
 */
data class ConversationListVO(
        val conversations: List<ConversationVO>
)