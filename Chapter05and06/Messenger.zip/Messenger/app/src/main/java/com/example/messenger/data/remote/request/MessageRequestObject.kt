package com.example.messenger.data.remote.request

/**
 * @author Iyanu Adelekan. 29/10/2017.
 */
data class MessageRequestObject(
        val recipientId: Long,
        val message: String
)