package com.example.messenger.ui.main

import android.app.Fragment
import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.FloatingActionButton
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.example.messenger.R
import com.example.messenger.data.local.AppPreferences
import com.example.messenger.data.vo.ConversationVO
import com.example.messenger.data.vo.UserVO
import com.example.messenger.ui.chat.ChatActivity
import com.example.messenger.ui.chat.ChatView
import com.example.messenger.ui.login.LoginActivity
import com.example.messenger.ui.settings.SettingsActivity

class MainActivity : AppCompatActivity(), MainView {

    private lateinit var llContainer: LinearLayout
    private lateinit var presenter: MainPresenter

    // Creation of fragment instances
    private val contactsFragment = ContactsFragment()
    private val conversationsFragment = ConversationsFragment()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        presenter = MainPresenterImpl(this)

        conversationsFragment.setActivity(this)
        contactsFragment.setActivity(this)

        bindViews()
        showConversationsScreen()
    }

    override fun bindViews() {
        llContainer = findViewById(R.id.ll_container)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun showConversationsLoadError() {
        Toast.makeText(this, "Unable to load conversations. Try again later.",
                Toast.LENGTH_LONG).show()
    }

    override fun showContactsLoadError() {
        Toast.makeText(this, "Unable to load contacts. Try again later.",
                Toast.LENGTH_LONG).show()
    }

    /**
     * Called to show the ConversationsFragment to the user
     */
    override fun showConversationsScreen() {
        /*
         * Begin a new fragment transaction and replace any fragment
         * present in activity's fragment container with a ConversationsFragment.
         */
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.ll_container, conversationsFragment)
        fragmentTransaction.commit()

        // Begin conversation loading process
        presenter.loadConversations()

        supportActionBar?.title = "Messenger"
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
    }

    /**
     * Called to show the ContactsFragment to the user
     */
    override fun showContactsScreen() {
        /*
         * Begin a new fragment transaction and replace any fragment
         * present in activity's fragment container with a ContactsFragment.
         */
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.ll_container, contactsFragment)
        fragmentTransaction.commit()
        presenter.loadContacts()

        supportActionBar?.title = "Contacts"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun showNoConversations() {
        Toast.makeText(this, "You have no active conversations.", Toast.LENGTH_LONG).show()
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            android.R.id.home -> showConversationsScreen()
            R.id.action_settings -> navigateToSettings()
            R.id.action_logout -> presenter.executeLogout()
        }

        return super.onOptionsItemSelected(item)
    }

    override fun getContext(): Context {
        return this
    }

    /**
     * Called to get the ContactsFragment of the activity
     * @return instance of type [ContactsFragment]
     */
    override fun getContactsFragment(): ContactsFragment {
        return contactsFragment
    }

    /**
     * Called to get the ConversationsFragment of the activity
     * @return instance of type [ConversationsFragment]
     */
    override fun getConversationsFragment(): ConversationsFragment {
        return conversationsFragment
    }

    override fun navigateToLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    override fun navigateToSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    /**
     * ConversationsFragment class extending the Fragment class
     */
    class ConversationsFragment : Fragment(), View.OnClickListener {

        private lateinit var activity: MainActivity
        private lateinit var rvConversations: RecyclerView
        private lateinit var fabContacts: FloatingActionButton
        var conversations: ArrayList<ConversationVO> = ArrayList()
        lateinit var conversationsAdapter: ConversationsAdapter

        /**
         * Function called when user interface of ConversationsFragment
         * is being drawn for the first time
         */
        override fun onCreateView(inflater: LayoutInflater, container: ViewGroup, savedInstanceState: Bundle?): View? {
            // fragment layout inflation
            val baseLayout = inflater.inflate(R.layout.fragment_conversations, container, false)

            // Layout view bindings
            rvConversations = baseLayout.findViewById(R.id.rv_conversations)
            fabContacts = baseLayout.findViewById(R.id.fab_contacts)

            conversationsAdapter  = ConversationsAdapter(getActivity(), conversations)

            // Setting the adapter of conversations recycler view to created conversations adapter
            rvConversations.adapter = conversationsAdapter

            // Setting the layout manager of conversations recycler view a linear layout manager
            rvConversations.layoutManager = LinearLayoutManager(getActivity().baseContext)

            fabContacts.setOnClickListener(this)

            return baseLayout
        }

        override fun onClick(view: View) {
            if (view.id == R.id.fab_contacts) {
                this.activity.showContactsScreen()
            }
        }

        fun setActivity(activity: MainActivity) {
            this.activity = activity
        }

        /**
         * Custom adapter for conversations recycler view
         * @property context
         * @property dataSet List containing data set of conversations recycler view
         */
        class ConversationsAdapter(private val context: Context, private val dataSet: List<ConversationVO>) :
                RecyclerView.Adapter<ConversationsAdapter.ViewHolder>(), ChatView.ChatAdapter {

            val preferences: AppPreferences = AppPreferences.create(context)

            /**
             * Invoked by RecyclerView in order to display data in the data set at a specified
             * position in the RecyclerView.
             */
            override fun onBindViewHolder(holder: ViewHolder, position: Int) {
                val item = dataSet[position] // get item at current position
                val itemLayout = holder.itemLayout // bind view holder layout to local variable

                // Setting data of layout's TextView widgets
                itemLayout.findViewById<TextView>(R.id.tv_username).text = item.secondPartyUsername
                itemLayout.findViewById<TextView>(R.id.tv_preview).text = item.messages[item.messages.size - 1].body

                // Setting View.OnClickListener of itemLayout
                itemLayout.setOnClickListener {
                    val message = item.messages[0]
                    val recipientId: Long

                    recipientId = if (message.senderId == preferences.userDetails.id) {
                        message.recipientId
                    } else {
                        message.senderId
                    }

                    navigateToChat(item.secondPartyUsername, recipientId, item.conversationId)
                }
            }

            /**
             * Invoked when the RecyclerView needs a new RecyclerView.ViewHolder instance
             * to represent an item in the data set
             */
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
                // Inflating the ViewHolder layout
                val itemLayout = LayoutInflater.from(parent.context)
                        .inflate(R.layout.vh_conversations, null, false)
                        .findViewById<LinearLayout>(R.id.ll_container)

                return ViewHolder(itemLayout)
            }

            /**
             * Called to get the number of items in data set
             */
            override fun getItemCount(): Int {
                return dataSet.size
            }

            /**
             * Navigates the user to conversation thread
             * @param recipientName name of chat recipient
             * @param recipientId unique id of recipient
             * @param conversationId unique id of active conversation
             */
            override fun navigateToChat(recipientName: String, recipientId: Long, conversationId: Long?) {
                val intent = Intent(context, ChatActivity::class.java)

                // Putting extra data into intent
                intent.putExtra("CONVERSATION_ID", conversationId)
                intent.putExtra("RECIPIENT_ID", recipientId)
                intent.putExtra("RECIPIENT_NAME", recipientName)

                context.startActivity(intent)
            }

            /**
             * @property itemLayout layout view of [ViewHolder]
             */
            class ViewHolder(val itemLayout: LinearLayout) : RecyclerView.ViewHolder(itemLayout)
        }
    }

    /**
     * ContactsFragment class extending Fragment class
     */
    class ContactsFragment : Fragment() {

        private lateinit var activity: MainActivity
        private lateinit var rvContacts: RecyclerView
        var contacts: ArrayList<UserVO> = ArrayList()
        lateinit var contactsAdapter: ContactsAdapter

        override fun onCreateView(inflater: LayoutInflater, container: ViewGroup, savedInstanceState: Bundle?): View? {
            val baseLayout = inflater.inflate(R.layout.fragment_contacts, container, false)
            rvContacts = baseLayout.findViewById(R.id.rv_contacts)
            contactsAdapter = ContactsAdapter(getActivity(), contacts)

            rvContacts.adapter = contactsAdapter
            rvContacts.layoutManager = LinearLayoutManager(getActivity().baseContext)

            return baseLayout
        }

        fun setActivity(activity: MainActivity) {
            this.activity = activity
        }

        class ContactsAdapter(private val context: Context, private val dataSet: List<UserVO>) :
                RecyclerView.Adapter<ContactsAdapter.ViewHolder>(), ChatView.ChatAdapter {

            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
                val itemLayout = LayoutInflater.from(parent.context)
                        .inflate(R.layout.vh_contacts, parent, false)
                val llContainer = itemLayout.findViewById<LinearLayout>(R.id.ll_container)

                return ViewHolder(llContainer)
            }

            override fun onBindViewHolder(holder: ViewHolder, position: Int) {
                val item = dataSet[position]
                val itemLayout = holder.itemLayout

                itemLayout.findViewById<TextView>(R.id.tv_username).text = item.username
                itemLayout.findViewById<TextView>(R.id.tv_phone).text = item.phoneNumber
                itemLayout.findViewById<TextView>(R.id.tv_status).text = item.status

                itemLayout.setOnClickListener {
                    navigateToChat(item.username, item.id)
                }
            }

            override fun getItemCount(): Int {
                return dataSet.size
            }

            override fun navigateToChat(recipientName: String, recipientId: Long, conversationId: Long?) {
                val intent = Intent(context, ChatActivity::class.java)
                intent.putExtra("RECIPIENT_ID", recipientId)
                intent.putExtra("RECIPIENT_NAME", recipientName)

                context.startActivity(intent)
            }

            class ViewHolder(val itemLayout: LinearLayout) : RecyclerView.ViewHolder(itemLayout)
        }
    }
}