package com.example.messenger.ui.main

/**
 * @author Iyanu Adelekan. 25/10/2017.
 */
interface MainPresenter {

    fun loadConversations()

    fun loadContacts()

    fun executeLogout()
}