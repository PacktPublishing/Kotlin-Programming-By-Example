package com.example.messenger.ui.signup

import com.example.messenger.ui.auth.AuthInteractor

/**
 * @author Iyanu Adelekan. 25/10/2017.
 */
interface SignUpInteractor : AuthInteractor {

    interface OnSignUpFinishedListener {
        fun onSuccess()

        fun onUsernameError()

        fun onPasswordError()

        fun onPhoneNumberError()

        fun onError()
    }

    fun signUp(username: String, phoneNumber: String, password: String, listener: OnSignUpFinishedListener)

    fun getAuthorization(listener: AuthInteractor.onAuthFinishedListener)
}