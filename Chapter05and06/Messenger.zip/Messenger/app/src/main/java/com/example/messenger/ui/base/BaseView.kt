package com.example.messenger.ui.base

import android.content.Context

/**
 * @author Iyanu Adelekan. 25/10/2017.
 */
interface BaseView {
    fun bindViews()

    fun getContext(): Context
}