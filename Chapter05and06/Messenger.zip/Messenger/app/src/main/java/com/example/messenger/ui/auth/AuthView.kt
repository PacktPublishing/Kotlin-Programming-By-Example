package com.example.messenger.ui.auth

/**
 * @author Iyanu Adelekan. 28/10/2017.
 */
interface AuthView {
    fun showAuthError()
}