package com.example.messenger.data.vo

/**
 * @author Iyanu Adelekan. 28/10/2017.
 */
data class UserVO(
        val id: Long,
        val username: String,
        val phoneNumber: String,
        val status: String,
        val createdAt: String
)