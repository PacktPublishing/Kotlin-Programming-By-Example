package com.example.messenger.ui.login

/**
 * @author Iyanu Adelekan. 25/10/2017.
 */
interface LoginPresenter {
    fun executeLogin(username: String, password: String)
}