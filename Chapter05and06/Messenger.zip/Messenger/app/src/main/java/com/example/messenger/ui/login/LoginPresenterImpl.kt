package com.example.messenger.ui.login

import com.example.messenger.data.local.AppPreferences
import com.example.messenger.ui.auth.AuthInteractor

/**
 * @author Iyanu Adelekan. 25/10/2017.
 */
class LoginPresenterImpl(private val view: LoginView) : LoginPresenter,
        AuthInteractor.onAuthFinishedListener, LoginInteractor.OnDetailsRetrievalFinishedListener {

    /*
     * Creation of interactor and preferences properties
     */
    private val interactor: LoginInteractor = LoginInteractorImpl()
    private val preferences: AppPreferences = AppPreferences.create(view.getContext())

    override fun onPasswordError() {
        view.hideProgress()
        view.setPasswordError()
    }

    override fun onUsernameError() {
        view.hideProgress()
        view.setUsernameError()
    }

    override fun onAuthSuccess() {
        interactor.persistAccessToken(preferences)

        /*
         * Uses interactor to retrieve details of the user
         */
        interactor.retrieveDetails(preferences, this)
    }

    override fun onAuthError() {
        view.showAuthError()
        view.hideProgress()
    }

    override fun onDetailsRetrievalSuccess() {
        interactor.persistUserDetails(preferences)
        view.hideProgress()
        view.navigateToHome()
    }

    override fun onDetailsRetrievalError() {
        /*
         * Uses interactor to retrieve details of the user
         */
        interactor.retrieveDetails(preferences, this)
    }

    /**
     * Called by a LoginView to request start of login process
     */
    override fun executeLogin(username: String, password: String) {
        view.showProgress()

        /*
         * Calls the interactor to begin the login process
         */
        interactor.login(username, password, this)
    }
}