package com.example.messenger.data.remote.repository

import android.content.Context
import com.example.messenger.service.MessengerApiService
import com.example.messenger.data.local.AppPreferences
import com.example.messenger.data.vo.UserListVO
import com.example.messenger.data.vo.UserVO
import io.reactivex.Observable

/**
 * @author Iyanu Adelekan. 27/10/2017.
 */
class UserRepositoryImpl(ctx: Context) : UserRepository {

    private val preferences: AppPreferences = AppPreferences.create(ctx)
    private val service: MessengerApiService = MessengerApiService.getInstance()

    override fun findById(id: Long): Observable<UserVO> {
        return service.showUser(id, preferences.accessToken as String)
    }

    override fun all(): Observable<UserListVO> {
        return service.listUsers(preferences.accessToken as String)
    }

    override fun echoDetails(): Observable<UserVO> {
        return service.echoDetails(preferences.accessToken as String)
    }
}